package br.edu.lista4.exe1;

public abstract class Ator {
    public abstract void ato();
}
