package br.edu.lista4.teste;

import br.edu.lista4.exe1.Palco;

public class MainPalco {
    public static void main(String[] args) {
        Palco palco1 = new Palco();
        palco1.atuar();
        palco1.altera();
        palco1.atuar();
        palco1.altera();
        palco1.atuar();
    }
}
